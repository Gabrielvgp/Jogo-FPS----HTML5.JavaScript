var camera, scene, renderer, controls;
var objectArma;
var objectCasa;
var objectZumbi;
var vp = 1;
var vb = 1;
var objectZumbi2;
var objectZumbi3;
var objectBase;
var objects = [];
var tiros= [];
var onObject ;
	var intersects ;
var pardeVB = 0.2;
var pardeVP = 0.2;
var Xzumbi1 = Math.random() * (18- (-20)) + (-20);
var Xzumbi2 = Math.random() * (18- (-20)) + (-20);
var Xzumbi3 = Math.random() * (18- (-20)) + (-20);

var Zzumbi = -Math.random() * (-100 - (-150)) + (-150);
var Zzumbi2 = -Math.random() * (-100 - (-150)) + (-150);
var Zzumbi3 = -Math.random() * (-100 - (-150)) + (-150);




var raycaster;
var blocker = document.getElementById( 'blocker' );
var instructions = document.getElementById( 'instructions' );

var havePointerLock = 'pointerLockElement' in document || 'mozPointerLockElement' in document || 'webkitPointerLockElement' in document;
if ( havePointerLock ) {
	var element = document.body;
	var pointerlockchange = function ( event ) {
		if ( document.pointerLockElement === element || document.mozPointerLockElement === element || document.webkitPointerLockElement === element ) {
			controlsEnabled = true;
			controls.enabled = true;
			blocker.style.display = 'none';
		} else {
			controls.enabled = false;
			blocker.style.display = 'block';
			instructions.style.display = '';
		}
	};
	var pointerlockerror = function ( event ) {
		instructions.style.display = '';
	};
	// Hook pointer lock state change events
	document.addEventListener( 'pointerlockchange', pointerlockchange, false );
	document.addEventListener( 'mozpointerlockchange', pointerlockchange, false );
	document.addEventListener( 'webkitpointerlockchange', pointerlockchange, false );
	document.addEventListener( 'pointerlockerror', pointerlockerror, false );
	document.addEventListener( 'mozpointerlockerror', pointerlockerror, false );
	document.addEventListener( 'webkitpointerlockerror', pointerlockerror, false );
	instructions.addEventListener( 'click', function ( event ) {
		instructions.style.display = 'none';

		element.requestPointerLock = element.requestPointerLock || element.mozRequestPointerLock || element.webkitRequestPointerLock;
		element.requestPointerLock();
	}, false );
} else {
	instructions.innerHTML = 'Your browser doesn\'t seem to support Pointer Lock API';
}
var controlsEnabled = false;
var moveForward = false;
var moveBackward = false;
var moveLeft = false;
var moveRight = false;
var canJump = false;
var prevTime = performance.now();
var velocity = new THREE.Vector3();
var direction = new THREE.Vector3();
var vertex = new THREE.Vector3();
var color = new THREE.Color();
var carros =[];
var fovy = 75;
var aspecto = window.innerWidth / window.innerHeight;
var near = 0.1 ;
var  far = 1000;
var camera = new THREE.PerspectiveCamera( fovy,aspecto, near, far );

var colisao;
init();
animate();
function init() {

	scene = new THREE.Scene();
	scene.background = new THREE.Color( 0xffffff );
	scene.fog = new THREE.Fog( 0xffffff, 0, 750 );
	var light = new THREE.HemisphereLight( 0xeeeeff, 0x777788, 0.75 );
	light.position.set( 0.5, 1, 0.75 );
	scene.add( light );
	controls = new THREE.PointerLockControls( camera );
	scene.add( controls.getObject() );
	var d = controls.getDirection(new THREE.Vector3());
	raycaster = new THREE.Raycaster( new THREE.Vector3(), new THREE.Vector3( 0, -1, 0), 0, 10 );

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



	renderer = new THREE.WebGLRenderer( { antialias: true } );
	renderer.setPixelRatio( window.devicePixelRatio );
	renderer.setSize( window.innerWidth, window.innerHeight );
	document.body.appendChild( renderer.domElement );
	//

}
function onWindowResize() {
	camera.aspect = window.innerWidth / window.innerHeight;
	camera.updateProjectionMatrix();
	renderer.setSize( window.innerWidth, window.innerHeight );
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////





function colidirCasas(){
	var d = controls.getDirection(new THREE.Vector3());
	var p = controls.getObject().position;
	var r = new THREE.Raycaster(p,d);
	intersects = r.intersectObjects([objectCasa,parede3,parede1,parede4,objectCaixa, objectCarro, objectCarro2, objectCarro3,objectBase], true );
  colisao = intersects.length >0;


}
function carregarcasa( object2 ) {

	objectCasa = object2;
	objectCasa.position.y =5;

objectCasa.scale.set(2,3,2);
	scene.add( objectCasa );
}

function carregarArma( object ) {
	objectArma = object;
	objectArma.position.z =-1 ;
	objectArma.position.y =-0.5;
	objectArma.position.x =0.5;
objectArma.scale.set(0.008,0.008,0.008);


		objectArma.rotation.y = 3;


	camera.add( objectArma );

}

function carregarZumbi( object ) {
	objectZumbi = object;
	objectZumbi.position.z = Zzumbi;
	objectZumbi.position.y =9;
	objectZumbi.position.x =Xzumbi1;
	objectZumbi.scale.set(5,5,5);

scene.add( objectZumbi );

}
function carregarZumbi3( object ) {
	objectZumbi3 = object;
	objectZumbi3.position.z = Zzumbi3;
	objectZumbi3.position.y =9;
	objectZumbi3.position.x =Xzumbi3;
	objectZumbi3.scale.set(5,5,5);



scene.add( objectZumbi3 );

}
function carregarZumbi2( object ) {
	objectZumbi2 = object;
	objectZumbi2.position.z = Xzumbi2;
	objectZumbi2.position.y =9;
	objectZumbi2.position.x =Xzumbi2;
	objectZumbi2.scale.set(5,5,5);

scene.add( objectZumbi2 );

}
function carregarBase( object ) {
	objectBase = object;
	objectBase.position.z = 120;
	//objectBase.position.y =+0.1;
	objectBase.position.x =-46;
	objectBase.scale.set(0.2,0.2,0.3);
		objectBase.rotation.y = Math.PI;

scene.add( objectBase );

}
function carregarcarro( object ) {
	objectCarro = object;
	objectCarro.position.z = -15;
	objectCarro.position.y =5;
	objectCarro.position.x =-39;
	objectCarro.scale.set(2,3,2);
		objectCarro.rotation.y = Math.PI +70 ;



scene.add( objectCarro );

}
var objectCaixa;
function carregarcaixa( object ) {
	objectCaixa = object;
	objectCaixa.position.z = 10;
	objectCaixa.position.y =5;
	objectCaixa.position.x =28;
	objectCaixa.scale.set(2,2,2);
	////	objectCaixa.rotation.y = Math.PI +70 ;



scene.add( objectCaixa );

}
function carregarcarro2( object ) {
	objectCarro2 = object;
	objectCarro2.position.z = 0;
	objectCarro2.position.y =11;
	objectCarro2.position.x =44;
	objectCarro2.scale.set(3,2,2);
		objectCarro2.rotation.y = -650;
		objectCarro2.rotation.z = 300;



scene.add( objectCarro2 );



}
function carregarcarro3( object ) {
	objectCarro3 = object;
	objectCarro3.position.z = 10;
	objectCarro3.position.y =5;
	objectCarro3.position.x =-36;
	objectCarro3.scale.set(2,3,2);
	objectCarro3.rotation.y = Math.PI +50 ;



scene.add( objectCarro3 );



}

var manager = new THREE.LoadingManager();
var loader = new THREE.OBJLoader( manager );

loader.load( 'cidade.obj', carregarcasa);
loader.load( 'M9.obj', carregarArma);
loader.load( 'ZOMBIE2.obj', carregarZumbi);
loader.load( 'ZOMBIE2.obj', carregarZumbi2);
loader.load( 'ZOMBIE2.obj', carregarZumbi3);
loader.load( 'Castle.obj', carregarBase);
loader.load( 'car.obj', carregarcarro);
loader.load( 'bus.obj', carregarcarro2);
loader.load( 'car.obj', carregarcarro3);
loader.load( 'caixa.obj', carregarcaixa);


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////




////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



var projetil ;


var spriteMapb = new THREE.TextureLoader().load( 'vidaB.png' );

var spriteMaterial= new THREE.SpriteMaterial( { map: spriteMapb} );

var spriteb = new THREE.Sprite( spriteMaterial );
spriteb.position.z = -1;
	spriteb.position.x = 1.41;
spriteb.position.y = 0.65;
spriteb.scale.set(0.15, 0.15, 1);

camera.add( spriteb );
///////////////////////////////////////////////////////////////////

var spriteMapP = new THREE.TextureLoader().load( 'ATIRADOR.png' );

var spriteMaterialP= new THREE.SpriteMaterial( { map: spriteMapP} );

var spriteP = new THREE.Sprite( spriteMaterialP );
spriteP.position.z = -1;
spriteP.position.x = -1.41;
spriteP.position.y = 0.65;
spriteP.rotation.y = 30;
spriteP.scale.set(0.15, 0.15, 1);

camera.add( spriteP );
///////////////////////////////////////////////////////////////////


var spriteMap = new THREE.TextureLoader().load( 'mira.png' );

var spriteMaterial2 = new THREE.SpriteMaterial( { map: spriteMap} );

var sprite = new THREE.Sprite( spriteMaterial2 );
sprite.position.z = -4;
sprite.position.x = 1.1;
sprite.scale.set(0.3, 0.3, 1)

camera.add( sprite );
///////////////////////////////////////////////////////////////////////////////////////



	var geometry = new THREE.SphereGeometry( 0.1, 32, 32 );
	var material = new THREE.MeshPhongMaterial( { color: 0xff0000 } );
		var materialparede = new THREE.MeshPhongMaterial( { color: 0xffffff } );

	var vida;
	var geometryvidaPersonagem =	new THREE.BoxGeometry(vp, 0.1,0.01 );
	var geometryparede1 =	new THREE.BoxGeometry(400, 20,1 );

	var geometryvidaBase = new THREE.BoxGeometry(vb, 0.1,0.01 );



	var parede1 = new THREE.Mesh( geometryparede1, materialparede );
	parede1.position.y = 10;

	parede1.position.z = -96;


	scene.add( parede1 );
	var geometryparede3=	new THREE.BoxGeometry(1, 20,400 );

	var parede3 = new THREE.Mesh( geometryparede3, materialparede );
	var parede4 = new THREE.Mesh( geometryparede3, materialparede );

	parede3.position.y = 10;

	parede3.position.x= -96;
	parede4.position.y = 10;

	parede4.position.x= 96;

	scene.add( parede4 );
		scene.add( parede3 );


	var vidap = new THREE.Mesh( geometryvidaPersonagem, material );
	var vidaBase = new THREE.Mesh( geometryvidaBase, material );

	vidap.position.x = 2.15;
	vidaBase.position.x = -2.15;

	vidap.position.y=1.35;
	vidaBase.position.y = 1.35;

	vidaBase.position.z = -2;

	vidap.position.z = -2;
	camera.add( vidap );
	camera.add( vidaBase );





function animate() {
	if(objectArma){	if (objectArma.position.z == -99) moveForward =false;}

/*	vidaBase.scale.x =1 -pardeVB;
	pardeVB =vb +pardeVB;*/

if (objectZumbi){//vida Personagem



	if(pardeVB <=1 && objectZumbi.position.x+2 >controls.getObject().position.x -3 && objectZumbi.position.x -2<=controls.getObject().position.x +3 && objectZumbi.position.z >=controls.getObject().position.z -3 && objectZumbi.position.z<=controls.getObject().position.z +5){
		objectZumbi.position.z =-Math.random() * (-100 - (-150)) + (-150);
		objectZumbi.position.x =  Math.random() * (18- (-20)) + (-20);
//vidap base
		vidaBase.scale.x =vb -pardeVB;
		pardeVB =0.2 +pardeVB;
	}
	//vida base



		if(pardeVB <=1 && objectZumbi2.position.x+2 >controls.getObject().position.x -3 && objectZumbi2.position.x -2<=controls.getObject().position.x +3 && objectZumbi2.position.z >=controls.getObject().position.z -3 && objectZumbi2.position.z<=controls.getObject().position.z +5){
		objectZumbi2.position.z = -Math.random() * (-100 - (-150)) + (-150);
		 		objectZumbi2.position.x = Math.random() * (18- (-20)) + (-20);

		vidaBase.scale.x =vb -pardeVB;
		pardeVB =0.2 +pardeVB;
	}



	if(pardeVB <=1 && objectZumbi3.position.x+2 >controls.getObject().position.x -3 && objectZumbi3.position.x -2<=controls.getObject().position.x +3 && objectZumbi3.position.z >=controls.getObject().position.z -3 && objectZumbi3.position.z<=controls.getObject().position.z +5){
		objectZumbi3.position.z = -Math.random() * (-100 - (-150)) + (-150);
		objectZumbi3.position.x =    Math.random() * (18- (-20)) + (-20);

		vidaBase.scale.x =vb -pardeVB;
		pardeVB =0.2 +pardeVB;
	}
if(objectBase){

		if (objectZumbi.position.z >= objectBase.position.z-75){
			objectZumbi.position.z =-Math.random() * (-100 - (-150)) + (-150);
			objectZumbi.position.x =  Math.random() * (18- (-20)) + (-20);
			vidap.scale.x =vb -pardeVP;
			pardeVP =0.2 +pardeVP;}
		if (objectZumbi2.position.z >= objectBase.position.z-75){
			objectZumbi2.position.z =-Math.random() * (-100 - (-150)) + (-150);
			objectZumbi2.position.x =  Math.random() * (18- (-20)) + (-20);
		vidap.scale.x =vb -pardeVP;
		pardeVP =0.2 +pardeVP;}
		if (objectZumbi3.position.z >= objectBase.position.z-75){
			objectZumbi3.position.z =-Math.random() * (-100 - (-150)) + (-150);
			objectZumbi3.position.x =  Math.random() *(18- (-20)) + (-20);
			vidap.scale.x =vb -pardeVP;
			pardeVP =0.2 +pardeVP;}
}}





if (objectZumbi){
	for (i=0; i< tiros.length; i++){
		if (tiros[i].position.x <= objectZumbi.position.x+3 && tiros[i].position.x >= objectZumbi.position.x-3 ){
		if (tiros[i].position.y <= objectZumbi.position.y+5 && tiros[i].position.y >= objectZumbi.position.y-5 ){
		if( tiros[i].position.z <= objectZumbi.position.z+3 && tiros[i].position.z >= objectZumbi.position.z-3 ){
			objectZumbi.position.z =-Math.random() * (-100 - (-150)) + (-150);
			objectZumbi.position.x =  Math.random() * (18- (-20)) + (-20);

	}}
	}
	if (tiros[i].position.x <= objectZumbi2.position.x+3 && tiros[i].position.x >= objectZumbi2.position.x-3 ){
	if (tiros[i].position.y <= objectZumbi2.position.y+5 && tiros[i].position.y >= objectZumbi2.position.y-5 ){
	if( tiros[i].position.z <= objectZumbi2.position.z+5 && tiros[i].position.z >= objectZumbi2.position.z-3 ){
		objectZumbi2.position.z =-Math.random() *(-100 - (-150)) + (-150);
		objectZumbi2.position.x =  Math.random() *(18- (-20)) + (-20);

}}}
	if (tiros[i].position.x <= objectZumbi3.position.x+3 && tiros[i].position.x >= objectZumbi3.position.x-3 ){
	if (tiros[i].position.y <= objectZumbi3.position.y+5 && tiros[i].position.y >= objectZumbi3.position.y-5 ){
	if( tiros[i].position.z <= objectZumbi3.position.z+3 && tiros[i].position.z >= objectZumbi3.position.z-3 ){
		objectZumbi3.position.z =-Math.random() * (-100 - (-150)) + (-150);
		objectZumbi3.position.x =  Math.random() * (18- (-20)) + (-20);

	}}
}}
if (pardeVB <=1 && pardeVP <=1){
 if ( objectZumbi) objectZumbi.position.z+=0.5;

  if ( objectZumbi2) objectZumbi2.position.z+=0.5;
	 if ( objectZumbi3) objectZumbi3.position.z+=0.5;}
	 else {			alert("Voce Perdeu, F5 para jogar novamente");}
}

	for (i = 0; i <tiros.length; i++) {



		tiros[i].position.x += tiros[i].direcao.x*10;
		tiros[i].position.y += tiros[i].direcao.y*10;
		tiros[i].position.z += tiros[i].direcao.z*10;




}
if(colisao == true){

var i = intersects[0].distance;
if (i <=8  ){
moveForward = false;}


}

	if ( controlsEnabled === true ) {

		raycaster.ray.origin.copy( controls.getObject().position );
							raycaster.ray.origin.y -=-5;
							var intersections = raycaster.intersectObjects( scene.children,true );
							var onObject = intersections.length > 0;

							if ( onObject === true ) {
						velocity.y = Math.max( 0, velocity.y );
						canJump = true;
					}

		var time = performance.now();
		var delta = ( time - prevTime ) / 1000;
		velocity.x -= velocity.x * 10.0 * delta;
		velocity.z -= velocity.z * 10.0 * delta;
		velocity.y -= 9.8 * 100.0 * delta; // 100.0 = mass
		direction.z = Number( moveForward ) - Number( moveBackward );
		direction.x = Number( moveLeft ) - Number( moveRight );
		direction.normalize(); // this ensures consistent movements in all directions
		if ( moveForward || moveBackward ) velocity.z -= direction.z * 400.0 * delta;
		if ( moveLeft || moveRight ) velocity.x -= direction.x * 400.0 * delta;
		if ( onObject === true ) {
			velocity.y = Math.max( 0, velocity.y );
			canJump = true;
		}
		controls.getObject().translateX( velocity.x * delta );
		controls.getObject().translateY( velocity.y * delta );
		controls.getObject().translateZ( velocity.z * delta );
		if ( controls.getObject().position.y < 10 ) {
			velocity.y = 0;
			controls.getObject().position.y = 10;
			canJump = true;
		}
		prevTime = time;
		colidirCasas();


	}

	renderer.render( scene, camera );

requestAnimationFrame( animate );
}




var onKeyDown = function ( event ) {
	console.log("TIRO");
	switch ( event.keyCode ) {
		case 38: // up
		case 87: // w

		moveForward = true;
		break;
		case 37: // left
		case 65: // a
		moveLeft = true; break;
		case 40: // down
		case 83: // s
		moveBackward = true;
		break;
		case 39: // right
		case 68: // d
		moveRight = true;
		break;
		case 32:

		if ( canJump === true ) velocity.y += 200;
		canJump = false;
		break;
	}
};
var onKeyUp = function ( event ) {
	switch( event.keyCode ) {
		case 38: // up
		case 87: // w

		moveForward = false;
		break;
		case 37: // left
		case 65: // a
		moveLeft = false;
		break;
		case 40: // down
		case 83: // s
		moveBackward = false;
		break;
		case 39: // right
		case 68: // d
		moveRight = false;
		break;
	}
};

function onWindowResize() {
	camera.aspect = window.innerWidth / window.innerHeight;
	camera.updateProjectionMatrix();
	renderer.setSize( window.innerWidth, window.innerHeight );
}


function  onClick(event){


	projetil = new THREE.Mesh( geometry, material )
	var pos = controls.getObject().localToWorld(new THREE.Vector3(0,0,0)); //controls.getObject().position;
	var dir =  controls.getDirection(new THREE.Vector3());

	projetil.position.x = 	pos.x;
	projetil.position.y = 	pos.y;
	projetil.position.z = 	pos.z;
	projetil.direcao = dir;
	tiros.push(projetil);


		scene.add( projetil );


}



window.addEventListener( 'keydown', onKeyDown, false );
window.addEventListener( 'keyup', onKeyUp, false );
window.addEventListener( 'resize', onWindowResize, false );
window.addEventListener( 'click', onClick, false );





//direção do controls controls.getDirection(new THREE Vector3 ())
